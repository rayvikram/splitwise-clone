from django.contrib import admin
from .models import Friend, UserGroup

admin.site.register(Friend)
admin.site.register(UserGroup)